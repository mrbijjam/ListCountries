package com.countriesinfo.data.model

class CountriesInfoResponse : ArrayList<CountiesInfoResponseItem>()