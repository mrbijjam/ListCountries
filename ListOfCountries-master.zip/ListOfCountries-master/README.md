Displayed the List of Countries in RecyclerView with out using dagger Framework.
